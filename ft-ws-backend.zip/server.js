const { WebSocketServer, WebSocket } = require("ws");
const PORT = process.env.PORT || 8080;

const sessions = {};
let totalConnections = 0;

const wss = new WebSocketServer({ port: PORT });
console.log(`🎬 FT WebSocket on port ${PORT}`);

wss.on("connection", (ws) => {
  const id = ++totalConnections;
  let clientSession = null, clientUserId = null, clientUserName = null;

  console.log(`[WS] #${id} connected`);

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch (e) { return; }
    const { type, ...data } = msg;

    if (type === "join-session") {
      clientSession = data.sessionId;
      clientUserId = data.userId;
      clientUserName = data.userName || data.userId;
      ws._ftUserId = clientUserId;
      ws._ftUserName = clientUserName;

      if (!sessions[clientSession]) sessions[clientSession] = new Set();
      sessions[clientSession].add(ws);

      broadcastToSession(clientSession, { type: "viewer-joined", userId: clientUserId, userName: clientUserName }, ws);
      broadcastViewerList(clientSession);
      console.log(`[WS] #${id} joined ${clientSession} as ${clientUserName}`);
      return;
    }

    if (type === "player-update") {
      broadcastToSession(data.sessionId, {
        type: "player-sync",
        currentTime: data.currentTime,
        isPlaying: data.isPlaying,
        fromUserId: data.userId,
      }, ws);
      return;
    }

    if (type === "send-chat") {
      broadcastToSession(data.sessionId, {
        type: "chat-received",
        userId: data.userId,
        userName: data.userName || "anon",
        message: data.message,
      }, ws);
      return;
    }

    if (type === "send-reaction") {
      broadcastToSession(data.sessionId, {
        type: "reaction-received",
        emoji: data.emoji,
        userId: data.userId,
        userName: data.userName || "anon",
      });
      return;
    }

    if (type === "send-snack") {
      broadcastToSession(data.sessionId, {
        type: "snack-received",
        emoji: data.emoji,
        userId: data.userId,
        userName: data.userName || "anon",
      });
      return;
    }

    if (type === "mark-moment") {
      broadcastToSession(data.sessionId, {
        type: "moment-marked",
        label: data.label,
        timestamp: data.timestamp,
        userId: data.userId,
        userName: data.userName || "anon",
      });
      return;
    }
  });

  ws.on("close", () => {
    console.log(`[WS] #${id} disconnected`);
    if (!clientSession) return;
    const set = sessions[clientSession];
    if (set) {
      set.delete(ws);
      if (set.size === 0) delete sessions[clientSession];
      else broadcastViewerList(clientSession);
    }
  });
});

function broadcastToSession(sessionId, data, excludeWs) {
  const set = sessions[sessionId];
  if (!set) return;
  const raw = JSON.stringify(data);
  set.forEach((c) => {
    if (c !== excludeWs && c.readyState === WebSocket.OPEN) c.send(raw);
  });
}

function broadcastViewerList(sessionId) {
  const set = sessions[sessionId];
  if (!set) return;
  const viewers = [];
  set.forEach((c) => {
    if (c._ftUserId) viewers.push({ id: c._ftUserId, name: c._ftUserName || c._ftUserId });
  });
  broadcastToSession(sessionId, { type: "viewer-list", viewers });
}

// Health check
require("http").createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/plain" });
  res.end(`FT WS OK — sessions:${Object.keys(sessions).length} total:${totalConnections}`);
}).listen(Number(PORT) + 1);

setInterval(() => {
  wss.clients.forEach((ws) => { if (ws.readyState === WebSocket.OPEN) ws.ping(); });
}, 30000);
